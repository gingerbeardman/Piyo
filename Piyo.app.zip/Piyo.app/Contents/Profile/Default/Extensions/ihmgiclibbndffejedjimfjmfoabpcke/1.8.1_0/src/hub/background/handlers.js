/* Kumquat Hub Background Handlers
 * 
**/

(function(undefined) {
  
  pl.extend(ke.app.handlers, {
    _proccessEventHandlers: {
      app: {
        translate: {},
        audio: {},
        option: {}
      }
    }
  });
  
})();