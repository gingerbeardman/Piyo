#instant translate

It is an extension for Google Chrome which provides instant translation of a selected text.

In this repository you can find localization files and graphics (screen shots, promotional images, et cetera). 
The mostly appreciated contribution is to translate Instant Translate into languages which are not supported yet.

Surely, [it is available on Web Store](https://chrome.google.com/webstore/detail/ihmgiclibbndffejedjimfjmfoabpcke).